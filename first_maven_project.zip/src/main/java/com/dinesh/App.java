package com.dinesh;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App
{
    public static void main( String[] args )
    {
        ApplicationContext appContext = new ClassPathXmlApplicationContext("spring.xml");
        Programmer objProgrammer = (Programmer) appContext.getBean("programmer");
        objProgrammer.writeCode();
    }
}
