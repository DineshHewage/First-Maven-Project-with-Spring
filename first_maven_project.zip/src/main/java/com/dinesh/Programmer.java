package com.dinesh;

public class Programmer {

    public void writeCode(){
        System.out.println("Programmer write code");
    }
}
